        <!-- jQuery 2.0.2 -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
		<script src="assets/js/app.js" type="text/javascript"></script>        <script>
		$(document).ready(function(){
		$("[data-toggle=tooltip]").tooltip();
		});
		</script>
        <script type="text/javascript">
            $(function() {
                //iCheck for checkbox and radio inputs
                $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
                    checkboxClass: 'icheckbox_minimal',
                    radioClass: 'iradio_minimal'
                });
            });
        </script>
