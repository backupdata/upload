<header class="header">
                <a href="Home.php"  class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining 
                <h1 style="background-color: #51C9AE;padding: 20px 20px 20px 20px;width: 160px;border-radius: 20px;font-size: 50px;margin-top: 2px;">LOGO</h1>-->
                <img src="assets/img/logo.jpg" alt="logo" style="height:100px;"/>

                </a>

            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
                       <li class="dropdown messages-menu" style="background-color: #ccc;">
                            <a href="Home.php" style="padding-bottom: 40px;padding-top: 40px;">
                                <i class="fa fa-home"></i>
                            </a>

                            
                        </li>
                        <!-- Tasks: style can be found in dropdown.less -->
                        <li class="dropdown tasks-menu">
                            <a href="#" style="padding-bottom: 40px;padding-top: 40px;">
                                <i class="fa fa-search"></i>
                            </a>
                            
                        </li>
                        <!-- Tasks: style can be found in dropdown.less -->
                        <li class="dropdown tasks-menu" >
                            <a href="#" style="padding-bottom: 40px;padding-top: 40px;">
                                <i class="fa fa-bell"></i>
                            </a>
                            
                        </li>
                        <!-- Tasks: style can be found in dropdown.less -->
                        <li class="dropdown tasks-menu">
                            <a href="#" style="padding-bottom: 40px;padding-top: 40px;">
                                <i class="fa fa-plus"></i>
                            </a>
                            
                        </li>
                        <!-- User Account: style can be found in dropdown.less -->
                        
                    </ul>
                </div>
            </nav>
        </header>