<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>AUDIT - Questions List</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- CSS.PHP (CSS Files) -->
        <?php include("include/css.php"); ?>    
        <!-- CSS.PHP (CSS Files) -->
    </head>
    <body class="skin-blue">
    <!-- Content Header (Page header) -->
	<?php include("include/header.php"); ?>
    <!-- Content Header (Page header) -->
                
                <!-- Main content -->
                <section class="">
                    <h1></h1>
               <div class="box box-solid">
               <div class="row">
               <div class="col-lg-12">
                 <div class="" style="padding-left: 44px;padding-right: 43px;padding-top: 30px;">
                  <div class="row">
                    <div class="col-md-8">
                    <div class="well">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:20px; padding-top:20px;">#1  Fixed Assets </div>
                <div class="panel panel-default arrow right" style="margin-bottom: 0px;">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">#1.1.1  Does the company maintain fixed asset Register/Cards </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:20px;">#1.1.2  Do these give the following particulers </div>
                  </header>
                  <div class="col-md-12">
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php"> i) Description of the asset </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published  col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">ii) Accounts classification </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">iii) Location </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">iv) Identification No </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">v) Quantity </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">vi) Original cost </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">vii) Depreciation rate, amount </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">viii) Details regarding disposal </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">ix) Year of purchase </a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  <header class="text-left">
                    <div class="date-published col-md-12" style="font-size:18px; padding-bottom:8px; padding-top:8px;"><a href="Details.php">x) Adjustment for revaluation(including AS 11 effect)</a></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <select class="form-control" name="" id="" >
                    <option value="">Select Options</option>
                    <option value="YES">YES</option>
                    <option value="NO">NO</option>
                    <option value="NOT APPLICABLE">NOT APPLICABLE</option>
                    </select>
                    </div></div>
                    <div class="form-group"><div class="comment-post col-md-5">
                    <textarea class="form-control" name="" id="" placeholder="" rows="1"></textarea>
                    </div></div>
                    
                  </header>
                  </div>
                  </div>
                 <!-- panel body end  -->
                  </div>
                  <!-- panel panel-default arrow right end  -->
                  </div>
                  <!-- well end  -->
                  </div>
                  <!-- col-md-8 end  -->
                  <div class="col-md-4">
                    <div class="well">
                    
                    </div>
                  <!-- well end  -->
                  </div>
                  <!-- col-md-4 end  -->
                  
                  </div>

                    </div>
                  </div>
                </div>
                
<br>
                </div>
                </div>
                </div>
                </section><!-- /.content -->
        <!-- JS.PHP (JS Files) -->
        <?php include("include/js.php"); ?>    
        <!-- JS.PHP (JS Files) -->
</body>
</html>