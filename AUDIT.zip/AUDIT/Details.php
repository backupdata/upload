<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>AUDIT - Questions List</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- CSS.PHP (CSS Files) -->
        <?php include("include/css.php"); ?>    
        <!-- CSS.PHP (CSS Files) -->
    </head>
    <body class="skin-blue">
    <!-- Content Header (Page header) -->
	<?php include("include/header.php"); ?>
    <!-- Content Header (Page header) -->
                
                <!-- Main content -->
                <section class="">
                    <h1></h1>
               <div class="box box-solid">
               <div class="row">
               <div class="col-lg-12">
               <div class="col-lg-12" style="padding-top: 30px;">
                </div>
                 <div class="" style="padding-left: 44px;padding-right: 43px;">
                  <div class="row">
                    <div class="col-md-8">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published" style="font-size:18px; padding-bottom:8px; padding-top:8px;">#1 • LOW • OPEN <span class="pull-right">
                        <a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Edit Issue"><i class="fa fa-pencil"></i> </a>
                        <a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Duplicate Issue"><i class="fa fa-plus-square"></i></a>
                        <a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Delete Issue"><i class="fa fa-trash-o"></i></a>
                    </span></div>
                    <span class="action" style="font-size:22px; padding-bottom:8px; padding-top:8px;"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
              </div>
            </div>
                    
                    </div>
                  </div>
  <div class="row">
    <div class="col-md-8">
      <hr>
      <!--<h2 class="page-header">Add a comment.</h2>-->
        <section class="comment-list">
          <!-- First Comment -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#1 • MAY 19, 2016 10:50</div>
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
          <!-- Second Comment Reply -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#2 • MAY 19, 2016 10:50 AM</div> 
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
          <!-- Third Comment -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#3 • MAY 19, 2016 10:50</div>
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
          <!-- Fourth Comment -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#4 • MAY 19, 2016 10:50</div>
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
          <!-- Fifth Comment -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#5 • MAY 19, 2016 10:50</div>
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
          <!-- Sixth Comment Reply -->
          <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
              <div class="avatar">
               <span>NV</span>
              </div>
            </div>
            <div class="col-md-10 col-sm-10">
              <div class="panel panel-default arrow right">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="date-published">#6 • MAY 19, 2016 10:50</div>
                    <span class="action"> Navin Vishnoi added a comment.</span>
                  </header>
                  <div class="comment-post">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </article>
        </section>
    </div>
  </div>
    <div class="row">
		<div class="col-md-8">
			<div class="well-green"><h3>This issue is in progress. You should be working on it.</h3></div>
      <h1 class="page-header">Add a comment.</h1>
			<div class="tabbable-panel">
				<div class="tabbable-line">
					<ul class="nav nav-tabs ">
						<li class="active">
							<a href="#tab_default_1" data-toggle="tab">
							Comment Only </a>
						</li>
					</ul>
					<div class="tab-content">
						<div class="tab-pane active" id="tab_default_1">
                        <div class="row">
                        <div class="col-md-12">
    						<div class="widget-area no-padding blank">
								<div class="status-upload">
									<form>
										<textarea placeholder="What are you doing right now?" ></textarea>
										<button type="submit" class="btn btn-success green" style="margin-bottom:11px;"> SUBMIT</button>
									</form>
								</div><!-- Status Upload  -->
							</div><!-- Widget Area -->
                            </div>
                            </div>
                        
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><br>
                </div>
                </div>
                </div>
                </section><!-- /.content -->
      
        <!-- JS.PHP (JS Files) -->
        <?php include("include/js.php"); ?>    
        <!-- JS.PHP (JS Files) -->
</body>
</html>