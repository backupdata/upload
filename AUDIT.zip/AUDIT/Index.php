<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>AUDIT - LOGIN PAGE</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
              <!-- bootstrap 3.0.2 -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="assets/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <style>
	 body{   overflow-x: hidden!important;
    font-family: 'Source Sans Pro', sans-serif;
    -webkit-font-smoothing: antialiased;
    min-height: 100%;
	background: none;}
	</style>
    </head>
    <body>

        <div class="form-box" id="login-box">
            <div class="header">
                <!--<img src="assets/img/DoneDone.png" class="img-responsible" alt="User Image" />-->
                <h1 style="background-color: #fff;padding: 20px 20px 20px 20px;width: 200px;margin-left: 69px;border-radius: 20px;font-size: 50px;"><img src="assets/img/logo.jpg" alt="logo" style="height:100px;"/></h1>
            </div>
            <div class="header"><strong>Login</strong></div>
            <form action="Home.php" method="post">
                <div class="body">
                    <div class="form-group">
                        <input type="text" name="number" class="form-control" placeholder="admin" maxlength="10" style="height: 43px;" />
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="********" style="height: 43px;" />
                    </div>
                </div>
                <div class="footer">                                                               
                    <button type="submit" class="btn btn-info btn-block" style="height: 43px;background-color:#51c9ae;border-color:#51c9ae;box-shadow: inset 0px 0px 0px 0px rgba(0, 0, 0, 0.09); font-size:20px;">Login</button>  
                </div>
            </form>

            
        </div>

        <!-- jQuery 2.0.2 -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/CSK.jpg", {speed: 500});
    </script>


  </body>
</html>